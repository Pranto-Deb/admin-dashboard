/*
Template Name: Tailwick - Admin & Dashboard Template
Author: Themesdesign
Website: https://themesdesign.in/
Contact: Themesdesign@gmail.com
File: plugins scroll hint init js
*/

new ScrollHint('.js-scrollable');